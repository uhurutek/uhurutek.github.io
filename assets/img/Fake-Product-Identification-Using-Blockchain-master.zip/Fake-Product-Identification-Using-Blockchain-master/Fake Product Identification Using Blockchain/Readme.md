## 🤔 Getting Started :

1. Go to the `blockchain-product-verification-react-main` <br>
Make Sure you are in the Main folder : 

``
blockchain-product-verification-react-main-20230425T165036Z-001\blockchain-product-verification-react-main
``
<br>
1. Install the Node_Modules
```
npm install
```

2. Build The Project
```
npm run build
```

3. Run The Project
```
npm run start
```
